


Pretty much.  At least the most recent incarnation of the conservatives. 



