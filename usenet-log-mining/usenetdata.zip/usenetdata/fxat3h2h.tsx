

Clay wrote: 

Not bad. You ain't as dumb as you sometimes appear. 
--  Sir Baldin Pramer, RPA 

